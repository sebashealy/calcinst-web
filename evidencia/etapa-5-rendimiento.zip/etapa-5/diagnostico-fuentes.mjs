import puppeteer from 'puppeteer-core';
const browser=await puppeteer.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});
try {
 const page=await browser.newPage();await page.setViewport({width:360,height:640,deviceScaleFactor:3});
 const pending=[];let gate=true;await page.setRequestInterception(true);page.on('request',r=>{if(gate&&r.resourceType()==='font')pending.push(r);else r.continue()});
 await page.goto('http://127.0.0.1:4321/',{waitUntil:'domcontentloaded'});
 const measure=()=>page.evaluate(()=>[...document.querySelectorAll('.hero > *, .acciones > *')].map(e=>({tag:e.tagName,cls:e.className,text:e.textContent.trim(),h:e.getBoundingClientRect().height,y:e.getBoundingClientRect().y,w:e.getBoundingClientRect().width,font:getComputedStyle(e).fontFamily})));
 console.log('ANTES',JSON.stringify(await measure()));
 gate=false;await Promise.all(pending.map(r=>r.continue()));await page.evaluate(()=>document.fonts.ready);
 console.log('DESPUES',JSON.stringify(await measure()));
} finally {await browser.close()}
